from dataclasses import dataclass, field
from datetime import datetime
import json
import os
from typing import Dict, Set, Any, Optional

# Global schedule storage
_schedules = {}
_next_id = 1

@dataclass
class Schedule:
    """Schedule data class for easier handling of schedule information"""
    id: int
    title: str
    description: str
    time: datetime
    br: str
    responses: Dict[str, Set[str]] = field(default_factory=lambda: {"참가": set(), "보류": set(), "미참가": set()})
    message_id: Optional[int] = None
    channel_id: Optional[int] = None
    notified: bool = False  # 알림 발송 여부 저장
    
    @classmethod
    def from_dict(cls, data):
        """Create a Schedule instance from dictionary data (for loading from JSON)"""
        # Convert ISO format back to datetime
        time = datetime.fromisoformat(data['time']) if isinstance(data['time'], str) else data['time']
        
        # Convert response lists back to sets
        responses = {}
        for key, value in data.get('responses', {}).items():
            responses[key] = set(value)
        
        return cls(
            id=data['id'],
            title=data['title'],
            description=data['description'],
            time=time,
            br=data['br'],
            responses=responses,
            message_id=data.get('message_id'),
            channel_id=data.get('channel_id'),
            notified=data.get('notified', False)  # 알림 발송 여부
        )
    
    def to_dict(self):
        """Convert Schedule to a dictionary (for JSON serialization)"""
        return {
            'id': self.id,
            'title': self.title,
            'description': self.description,
            'time': self.time.isoformat(),
            'br': self.br,
            'responses': {key: list(value) for key, value in self.responses.items()},
            'message_id': self.message_id,
            'channel_id': self.channel_id,
            'notified': self.notified  # 알림 발송 여부 저장
        }


def get_schedules() -> Dict[int, Schedule]:
    """Get the schedules dictionary"""
    global _schedules
    return _schedules


def get_next_id() -> int:
    """Get the next available schedule ID"""
    global _next_id
    current_id = _next_id
    _next_id += 1
    return current_id


def save_schedules(schedules=None):
    """Save schedules to a JSON file"""
    global _schedules
    if schedules is not None:
        _schedules = schedules
    
    # Convert schedules to serializable format
    serializable = {}
    for schedule_id, schedule in _schedules.items():
        serializable[schedule_id] = schedule.to_dict()
    
    # Save to file
    with open('schedules.json', 'w', encoding='utf-8') as f:
        json.dump(serializable, f, ensure_ascii=False, indent=2)


def load_schedules():
    """Load schedules from JSON file"""
    global _schedules, _next_id
    
    if not os.path.exists('schedules.json'):
        return
    
    with open('schedules.json', 'r', encoding='utf-8') as f:
        data = json.load(f)
    
    _schedules = {}
    max_id = 0
    
    for schedule_id, schedule_data in data.items():
        schedule_id = int(schedule_id)
        _schedules[schedule_id] = Schedule.from_dict(schedule_data)
        max_id = max(max_id, schedule_id)
    
    # Set next_id to one more than the highest existing ID
    _next_id = max_id + 1
