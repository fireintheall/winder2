from datetime import datetime, timedelta, timezone
import re

# 한국 시간대 설정 (UTC+9)
KST = timezone(timedelta(hours=9))

def get_current_time_kst() -> datetime:
    """현재 한국 시간(KST)을, 시간대 정보가 포함된 datetime 객체로 반환"""
    return datetime.now().replace(tzinfo=timezone.utc).astimezone(KST)

def is_valid_datetime_format(datetime_str: str) -> bool:
    """Check if a string matches the datetime format YYYY-MM-DD HH:MM"""
    pattern = r"^\d{4}-\d{2}-\d{2} \d{2}:\d{2}$"
    return bool(re.match(pattern, datetime_str))

def parse_datetime(datetime_str: str) -> datetime:
    """Parse a datetime string in the format YYYY-MM-DD HH:MM (KST)"""
    if not is_valid_datetime_format(datetime_str):
        raise ValueError("Invalid datetime format. Expected format: YYYY-MM-DD HH:MM")
    
    try:
        # KST 시간대를 적용
        dt = datetime.strptime(datetime_str, "%Y-%m-%d %H:%M")
        return dt.replace(tzinfo=KST)
    except ValueError:
        raise ValueError("Invalid date or time values")

def format_datetime(dt: datetime) -> str:
    """Format a datetime object to string in the format YYYY-MM-DD HH:MM (KST)"""
    # 시간대가 설정되지 않은 경우 KST로 설정
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=KST)
    return dt.strftime("%Y-%m-%d %H:%M") + " (KST)"
