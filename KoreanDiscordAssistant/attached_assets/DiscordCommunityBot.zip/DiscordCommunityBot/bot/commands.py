import discord
from discord.ext import commands
from discord import app_commands
import logging
from .views import ScheduleView, ScheduleModal
from .models import Schedule, get_schedules, get_next_id, save_schedules
from datetime import datetime

logger = logging.getLogger(__name__)

def register_commands(bot):
    """Register all slash commands and traditional commands"""
    
    # Slash Commands
    @bot.tree.command(name="일정추가", description="새 일정을 추가합니다.")
    async def add_schedule(interaction: discord.Interaction):
        """Add a new schedule"""
        await interaction.response.send_modal(ScheduleModal())
    
    @bot.tree.command(name="일정목록", description="모든 일정을 보여줍니다.")
    async def list_schedules(interaction: discord.Interaction):
        """List all schedules"""
        schedules = get_schedules()
        
        if not schedules:
            await interaction.response.send_message("❌ 등록된 일정이 없습니다.", ephemeral=True)
            return
        
        embed = discord.Embed(title="📅 일정 목록", description="현재 등록된 모든 일정입니다.")
        
        for schedule_id, schedule in schedules.items():
            embed.add_field(
                name=f"#{schedule_id}: {schedule.title}",
                value=f"시간: {schedule.time.strftime('%Y-%m-%d %H:%M')}\nBR: {schedule.br}",
                inline=False
            )
        
        await interaction.response.send_message(embed=embed, ephemeral=True)
    
    @bot.tree.command(name="일정삭제", description="기존 일정을 삭제합니다.")
    @app_commands.describe(일정id="삭제할 일정의 ID")
    async def delete_schedule(interaction: discord.Interaction, 일정id: int):
        """Delete a schedule by ID"""
        schedules = get_schedules()
        
        if 일정id not in schedules:
            await interaction.response.send_message("❌ 해당 일정ID가 존재하지 않습니다.", ephemeral=True)
            return
        
        schedule = schedules[일정id]
        
        # Delete the original message if possible
        if schedule.message_id and schedule.channel_id:
            try:
                channel = bot.get_channel(schedule.channel_id)
                if channel:
                    try:
                        message = await channel.fetch_message(schedule.message_id)
                        await message.delete()
                    except discord.NotFound:
                        pass  # Message already deleted
            except Exception as e:
                logger.error(f"일정 메시지 삭제 실패: {e}")
        
        # Remove from schedules dict
        del schedules[일정id]
        save_schedules(schedules)
        
        await interaction.response.send_message(f"✅ 일정 #{일정id}가 삭제되었습니다.", ephemeral=True)
    
    # Traditional Commands
    @bot.command(name="일정현황")
    async def schedule_status(ctx, 일정id: int):
        """Show the current status of a schedule"""
        schedules = get_schedules()
        
        if 일정id not in schedules:
            await ctx.send("❌ 해당 일정ID가 존재하지 않습니다.")
            return
        
        schedule = schedules[일정id]
        embed = discord.Embed(title=f"📊 응답 현황 - 일정 #{일정id}: {schedule.title}")
        
        responses = schedule.responses if hasattr(schedule, 'responses') else {"참가": set(), "보류": set(), "미참가": set()}
        
        for rtype, users in responses.items():
            # ID:닉네임 형식에서 닉네임만 추출하여 표시
            display_names = []
            for user_data in users:
                if ":" in user_data:
                    # ID:닉네임 형식인 경우
                    _, display_name = user_data.split(":", 1)
                    display_names.append(display_name)
                else:
                    # 기존 데이터 형식(호환성 유지)
                    display_names.append(user_data)
            
            names = ', '.join(display_names) if display_names else "없음"
            embed.add_field(name=f"{rtype} ({len(users)})", value=names, inline=False)
        
        await ctx.send(embed=embed)
    
    @bot.command(name="도움말")
    async def help_command(ctx):
        """Show help information"""
        embed = discord.Embed(title="📅 일정 관리 봇 도움말", description="사용 가능한 명령어 목록")
        
        embed.add_field(
            name="/ 명령어",
            value=(
                "`/일정추가` - 새 일정을 추가합니다.\n"
                "`/일정목록` - 모든 일정을 보여줍니다.\n"
                "`/일정삭제 [일정id]` - 일정을 삭제합니다."
            ),
            inline=False
        )
        
        embed.add_field(
            name="! 명령어",
            value=(
                "`!일정현황 [일정id]` - 해당 일정의 응답 현황을 보여줍니다.\n"
                "`!도움말` - 이 도움말을 보여줍니다."
            ),
            inline=False
        )
        
        await ctx.send(embed=embed)
    
    # Error handling
    @bot.event
    async def on_command_error(ctx, error):
        if isinstance(error, commands.MissingRequiredArgument):
            await ctx.send("❌ 필요한 인자가 누락되었습니다. `!도움말` 명령어로 사용법을 확인하세요.")
        elif isinstance(error, commands.BadArgument):
            await ctx.send("❌ 잘못된 인자 형식입니다. 숫자가 필요한 곳에 숫자를 입력하세요.")
        else:
            logger.error(f"명령어 오류: {error}")
            await ctx.send(f"❌ 오류가 발생했습니다: {error}")
