import discord
from discord.ext import commands
import logging
import json
import os
from .models import Schedule, get_schedules, save_schedules

logger = logging.getLogger(__name__)

def create_bot():
    """Create and configure the Discord bot"""
    intents = discord.Intents.default()
    intents.message_content = True
    
    bot = commands.Bot(command_prefix="!", intents=intents)
    
    # Import commands after bot is created to avoid circular imports
    from .commands import register_commands
    
    @bot.event
    async def on_ready():
        try:
            # Register all commands first
            register_commands(bot)
            
            # 기존 명령어 지우기
            bot.tree.clear_commands(guild=None)
            
            # 명령어 동기화
            synced = await bot.tree.sync()
            
            # 성공 로그
            logger.info(f"봇 로그인 완료: {bot.user} / {len(synced)}개의 명령어 동기화됨")
            
            # 명령어 목록 출력
            command_names = [cmd.name for cmd in synced]
            logger.info(f"동기화된 명령어 목록: {', '.join(command_names)}")
        except Exception as e:
            logger.error(f"명령어 동기화 실패: {e}")
    
    # Load saved schedules
    if os.path.exists('schedules.json'):
        try:
            with open('schedules.json', 'r', encoding='utf-8') as f:
                data = json.load(f)
                loaded_schedules = {}
                
                for schedule_id, schedule_data in data.items():
                    loaded_schedules[int(schedule_id)] = Schedule.from_dict(schedule_data)
                
                logger.info(f"기존 일정 {len(loaded_schedules)}개 로드 완료")
        except Exception as e:
            logger.error(f"일정 로드 실패: {e}")
    
    return bot
