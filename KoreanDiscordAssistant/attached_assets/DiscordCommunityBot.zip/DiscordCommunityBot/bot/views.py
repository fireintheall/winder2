import discord
from discord import ui
from datetime import datetime
import logging
from .models import Schedule, get_schedules, get_next_id, save_schedules

logger = logging.getLogger(__name__)

class ScheduleView(discord.ui.View):
    """View class for schedule response buttons"""
    
    def __init__(self, schedule_id, timeout_seconds=None):
        super().__init__(timeout=timeout_seconds)
        self.schedule_id = schedule_id
        self.responses = {"참가": set(), "보류": set(), "미참가": set()}
        
        # Load saved responses if available
        schedules = get_schedules()
        if schedule_id in schedules and hasattr(schedules[schedule_id], 'responses'):
            self.responses = schedules[schedule_id].responses
    
    @discord.ui.button(label="참가", style=discord.ButtonStyle.success)
    async def join_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        try:
            await self.respond(interaction, "참가")
        except Exception as e:
            logger.error(f"참가 버튼 처리 중 오류: {str(e)}")
            await interaction.response.send_message("⚠️ 응답 처리 중 오류가 발생했습니다. 나중에 다시 시도해주세요.", ephemeral=True)
    
    @discord.ui.button(label="보류", style=discord.ButtonStyle.primary)
    async def maybe_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        try:
            await self.respond(interaction, "보류")
        except Exception as e:
            logger.error(f"보류 버튼 처리 중 오류: {str(e)}")
            await interaction.response.send_message("⚠️ 응답 처리 중 오류가 발생했습니다. 나중에 다시 시도해주세요.", ephemeral=True)
    
    @discord.ui.button(label="미참가", style=discord.ButtonStyle.danger)
    async def decline_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        try:
            await self.respond(interaction, "미참가")
        except Exception as e:
            logger.error(f"미참가 버튼 처리 중 오류: {str(e)}")
            await interaction.response.send_message("⚠️ 응답 처리 중 오류가 발생했습니다. 나중에 다시 시도해주세요.", ephemeral=True)
    
    async def respond(self, interaction: discord.Interaction, response_type):
        """Handle user response to schedule"""
        # 사용자의 서버 닉네임을 사용 (없을 경우 기본 이름 사용)
        user_id = str(interaction.user.id)  # 고유 ID를 사용하여 사용자 식별
        display_name = interaction.user.display_name  # 서버 닉네임
        
        # 저장할 때는 ID:닉네임 형태로 저장
        user_data = f"{user_id}:{display_name}"
        
        # 먼저 응답 보내기
        try:
            await interaction.response.defer(ephemeral=True)
        except Exception as e:
            # defer 실패 시 무시하고 진행
            logger.warning(f"응답 지연 실패: {str(e)}")
            
        # Remove user from all response types
        for rtype in self.responses:
            # ID로 시작하는 항목 찾아서 제거
            to_remove = None
            for item in self.responses[rtype]:
                if isinstance(item, str) and item.startswith(f"{user_id}:"):
                    to_remove = item
                    break
            if to_remove:
                self.responses[rtype].discard(to_remove)
        
        # Add user to selected response type
        self.responses[response_type].add(user_data)
        
        # Update the schedule in storage
        schedules = get_schedules()
        if self.schedule_id in schedules:
            schedule = schedules[self.schedule_id]
            schedule.responses = self.responses
            save_schedules(schedules)
        
        # 메시지 업데이트
        try:
            await self.update_message(interaction)
        except Exception as e:
            logger.error(f"메시지 업데이트 중 오류: {str(e)}")
        
        # 응답 완료 메시지 전송
        try:
            await interaction.followup.send(f"{display_name}님이 '{response_type}'로 응답했습니다.", ephemeral=True)
        except Exception as e:
            logger.error(f"응답 메시지 전송 중 오류: {str(e)}")
    
    async def update_message(self, interaction):
        """Update the schedule message with current responses"""
        # interaction을 통해 작업하고 봇 인스턴스에 직접 의존하지 않음
        # interaction.client가 봇 인스턴스임
        if not interaction or not interaction.client:
            logger.error("상호작용 객체나 봇 클라이언트가 없습니다. 메시지를 업데이트할 수 없습니다.")
            return
            
        schedules = get_schedules()
        if self.schedule_id not in schedules:
            return
        
        schedule = schedules[self.schedule_id]
        embed = discord.Embed(title=f"📅 일정 #{self.schedule_id}: {schedule.title}", description=schedule.description)
        embed.add_field(name="시간", value=schedule.time.strftime("%Y-%m-%d %H:%M"), inline=True)
        embed.add_field(name="BR", value=schedule.br, inline=True)
        
        # 응답자 정보 처리
        guild = None
        if interaction and hasattr(interaction, 'guild'):
            guild = interaction.guild
            
        for rtype, users in self.responses.items():
            # 사용자 이름과 태그를 구성
            display_names = []
            mentions = []
            
            for user_data in users:
                if isinstance(user_data, str) and ":" in user_data:
                    # ID:닉네임 형식인 경우
                    user_id, display_name = user_data.split(":", 1)
                    display_names.append(display_name)
                    mentions.append(f"<@{user_id}>")  # 멘션용 형식
                else:
                    # 기존 데이터 형식(호환성 유지)
                    display_names.append(str(user_data))
                    mentions.append(str(user_data))
                    
            # 태그 형식으로 닉네임 표시
            if mentions:
                tag_text = " ".join(mentions)
                embed.add_field(name=f"{rtype} ({len(users)})", value=tag_text, inline=False)
            else:
                embed.add_field(name=f"{rtype} (0)", value="없음", inline=False)
        
        # 일정 업데이트 시간 표시
        embed.set_footer(text=f"마지막 업데이트: {datetime.now().strftime('%Y-%m-%d %H:%M')}")
        
        # 메시지 업데이트 시도 (채널부터 확인)
        success = False
        
        # 채널 ID와 메시지 ID로 업데이트 시도 (가장 안정적)
        if hasattr(schedule, 'message_id') and hasattr(schedule, 'channel_id') and schedule.message_id and schedule.channel_id:
            try:
                # 채널 가져오기
                channel = None
                try:
                    channel_id = int(schedule.channel_id)
                    # Bot 인스턴스를 얻는 다양한 방법 시도
                    from discord.ext import commands
                    
                    # 방법 1: interaction.client 사용
                    bot = None
                    if interaction and hasattr(interaction, 'client'):
                        bot = interaction.client
                    
                    # 방법 2: 글로벌 변수 가져오기 시도
                    if not bot:
                        try:
                            import main
                            bot = main.bot_instance
                        except:
                            pass
                    
                    # 채널 가져오기
                    channel = None
                    if bot:
                        channel = bot.get_channel(channel_id)
                        if not channel:
                            try:
                                channel = await bot.fetch_channel(channel_id)
                            except:
                                pass
                except:
                    pass
                
                if channel and hasattr(channel, 'fetch_message'):
                    try:
                        # 메시지 가져오기
                        message = await channel.fetch_message(int(schedule.message_id))
                        await message.edit(embed=embed, view=self)
                        success = True
                        return
                    except discord.NotFound:
                        logger.warning(f"일정 메시지(ID: {schedule.message_id})를 찾을 수 없습니다.")
                    except Exception as e:
                        logger.error(f"일정 메시지 업데이트 실패: {e}")
            except Exception as e:
                logger.error(f"채널 또는 메시지 가져오기 실패: {e}")
        
        # 인터랙션 메시지로 업데이트 시도 (대체 방법)
        if not success:
            try:
                if interaction and hasattr(interaction, 'message') and interaction.message:
                    await interaction.message.edit(embed=embed, view=self)
                    success = True
                    return
            except Exception as e:
                logger.warning(f"인터랙션 메시지 업데이트 실패: {e}")
        
        # 모든 방법 실패 시 로그
        if not success:
            logger.warning(f"일정 #{self.schedule_id}의 메시지를 업데이트할 수 없습니다.")


class ScheduleModal(discord.ui.Modal, title="📋 새 일정 추가"):
    """Modal for adding a new schedule"""
    
    제목 = discord.ui.TextInput(label="제목", placeholder="일정 제목", max_length=100)
    내용 = discord.ui.TextInput(label="내용", placeholder="일정에 대한 설명", style=discord.TextStyle.paragraph)
    시간 = discord.ui.TextInput(label="시간", placeholder="예: 2025-05-10 19:00")
    BR = discord.ui.TextInput(label="BR", placeholder="BR 정보를 입력하세요")
    
    async def on_submit(self, interaction: discord.Interaction):
        """Handle schedule submission"""
        try:
            일정시간 = datetime.strptime(self.시간.value, "%Y-%m-%d %H:%M")
        except ValueError:
            await interaction.response.send_message("❌ 시간 형식이 잘못되었습니다. 예: `2025-05-10 19:00`", ephemeral=True)
            return
        
        # 봇 인스턴스 직접 참조하지 않음 (interaction을 통해 작업)
        
        # 일정 ID 생성
        일정ID = get_next_id()
        view = ScheduleView(schedule_id=일정ID, timeout_seconds=None)
        
        embed = discord.Embed(title=f"📅 일정 #{일정ID}: {self.제목.value}", description=self.내용.value)
        embed.add_field(name="시간", value=일정시간.strftime("%Y-%m-%d %H:%M"), inline=True)
        embed.add_field(name="BR", value=self.BR.value, inline=True)
        embed.set_footer(text="아래 버튼을 눌러 응답하세요!")
        
        # 채널에 메시지 전송
        message = await interaction.channel.send(embed=embed, view=view)
        
        # Create and save schedule
        schedules = get_schedules()
        schedules[일정ID] = Schedule(
            id=일정ID,
            title=self.제목.value,
            description=self.내용.value,
            time=일정시간,
            br=self.BR.value,
            responses={"참가": set(), "보류": set(), "미참가": set()},
            message_id=message.id,
            channel_id=message.channel.id
        )
        save_schedules(schedules)
        
        # 사용자에게 알림
        try:
            await interaction.response.send_message(f"✅ 일정이 생성되었습니다! (ID: {일정ID})", ephemeral=True)
        except discord.errors.InteractionResponded:
            # 이미 응답이 된 경우 (뷰에서 응답을 보냈거나 timeout 등) 무시
            logger.debug("일정 생성 확인 메시지가 전송되지 않음: 이미 상호작용에 응답함")
        except Exception as e:
            logger.error(f"일정 생성 확인 메시지 전송 중 오류: {e}")
